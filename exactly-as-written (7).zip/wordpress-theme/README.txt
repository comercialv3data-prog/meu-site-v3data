=== TEMA IEGO PARA WORDPRESS ===

INSTRUÇÕES DE INSTALAÇÃO:

1. PREPARAR OS ARQUIVOS:
   - Remova a extensão .txt de todos os arquivos
   - Os arquivos devem ficar: style.css, functions.php, header.php, etc.

2. CRIAR PASTA DO TEMA:
   - Acesse seu servidor via FTP ou painel de controle
   - Vá para: wp-content/themes/
   - Crie uma nova pasta chamada "iego-theme"

3. FAZER UPLOAD DOS ARQUIVOS:
   - Faça upload de todos os arquivos para a pasta iego-theme:
     * style.css
     * functions.php
     * index.php
     * header.php
     * footer.php
     * page.php
     * single.php

4. ATIVAR O TEMA:
   - Entre no painel do WordPress
   - Vá em Aparência > Temas
   - Encontre o tema "IEGO Dashboard"
   - Clique em "Ativar"

5. CONFIGURAR MENUS:
   - Vá em Aparência > Menus
   - Crie um menu chamado "Menu Principal"
   - Atribua ao local "Menu Principal"
   - Adicione as páginas desejadas

6. PERSONALIZAR:
   - Para mudar o número do WhatsApp, edite o shortcode no footer.php
   - Você pode personalizar cores no style.css
   - Adicione seu logo em Aparência > Personalizar > Identidade do Site

7. CRIAR PÁGINAS IMPORTANTES:
   - Crie uma página "Demo"
   - Crie uma página "Contato"
   - Defina uma página como página inicial em Configurações > Leitura

ESTRUTURA DOS ARQUIVOS:

- style.css: Estilos do tema e informações do tema
- functions.php: Funções e recursos do tema
- header.php: Cabeçalho do site
- footer.php: Rodapé do site
- index.php: Template da página inicial e listagem de posts
- page.php: Template para páginas
- single.php: Template para posts individuais

RECURSOS INCLUÍDOS:

✓ Design responsivo
✓ Botão flutuante do WhatsApp
✓ Menu de navegação
✓ Suporte a widgets
✓ Suporte a imagens destacadas
✓ Sistema de comentários
✓ SEO-friendly
✓ Design baseado no site IEGO

SHORTCODES DISPONÍVEIS:

[whatsapp number="5511999999999" message="Sua mensagem aqui"]

SUPORTE:

Para personalização adicional, você pode:
- Contratar um desenvolvedor WordPress
- Editar o arquivo style.css para ajustar cores e espaçamentos
- Adicionar plugins para funcionalidades extras

PLUGINS RECOMENDADOS:

- Contact Form 7 (para formulários)
- Yoast SEO (para otimização)
- WP Rocket (para cache e performance)
- Elementor (para edição visual de páginas)

Boa sorte com seu site WordPress!
